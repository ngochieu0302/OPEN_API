# Tipped
A Complete Javascript Tooltip Solution

https://www.tippedjs.com

---

Tipped has been open-sourced under the [Creative Commons BY 4.0 license](https://creativecommons.org/licenses/by/4.0) as of nov. 25 2019.
