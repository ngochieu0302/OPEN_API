var Tipped = {};

$.extend(Tipped, {
  version: '<%= pkg.version %>'
});
