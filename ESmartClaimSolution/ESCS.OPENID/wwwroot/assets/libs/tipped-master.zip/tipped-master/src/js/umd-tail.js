Tipped.init();

return Tipped;

}));